# ORVIA AI – v0.1.0

Bilingual (English / Af-Soomaali) Windows desktop assistant built with Electron, React and Vite.

## What works in this version

- Electron shell with secure settings: context isolation, sandbox, no Node in the renderer, a
  whitelisted preload API, and a permission handler that only grants microphone access.
- System tray icon, minimize/close to tray, single-instance lock, launch-at-startup option.
- Full English and Somali UI through a central dictionary (`src/i18n.js`). The choice persists.
- Dashboard with system status, quick actions, recently used apps and recent conversations.
- AI chat using the Anthropic Messages API. The key is encrypted with Electron `safeStorage`
  (Windows DPAPI) and never leaves the main process.
- Voice page: push-to-talk through the Web Speech API, with spoken replies through speech synthesis.
- Opening whitelisted Windows apps and settings pages by typed or spoken command, in English or Somali.
  Examples: "ORVIA, open Microsoft Word." / "ORVIA, fur Microsoft Word."
- Activity log showing actions ORVIA performed.

## Not built yet (shown as "planned" in the app, not simulated)

- Wake word ("Hey ORVIA") and microphone sensitivity settings
- Offline AI through Ollama, and offline speech/TTS models
- Document reader, Study Assistant, Translation module
- File manager, music control, volume/window control, WhatsApp automation
- SQLite conversation history (currently held in memory for the session)
- Somali speech recognition depends on the engine. Chromium's built-in engine may not support `so-SO`;
  test it on your machine. A pluggable speech provider is the planned fix.

## Run in development

Requirements: Node.js 20+ and Windows 10/11 for full functionality.

    npm install
    npm start

## Add your AI key

Settings → AI provider → paste your Anthropic API key → Save key. It is stored encrypted for your
Windows user account. Choose the model in the same section.

## Build the Windows installer

Run on Windows:

    npm install
    npm run dist

The installer is written to `release/` and creates desktop and Start Menu shortcuts.
Add `build/icon.ico` (256×256 multi-size) before a release build; without it the default icon is used.

## Architecture

- `electron/main.js` – trusted main process: settings, key storage, AI calls, app launching, tray, logging.
- `electron/preload.js` – the only bridge to the renderer (`window.orvia`).
- `src/` – React UI, i18n and styles.

To add a feature, add an IPC channel in `main.js`, expose it in `preload.js`, and call it from the UI.
Never pass renderer input to a shell command. Add new apps to the `APPS` map instead.
