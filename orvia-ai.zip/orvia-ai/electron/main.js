const { app, BrowserWindow, Tray, Menu, ipcMain, safeStorage, nativeImage, shell, session } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { spawn } = require('child_process');

const ANTHROPIC_URL = 'https://api.anthropic.com/v1/messages';

const DEFAULTS = {
  language: 'en',
  theme: 'dark',
  model: 'claude-sonnet-5-5',
  closeToTray: true,
  launchAtStartup: false,
  voiceRate: 1,
  recentApps: [],
};

// Whitelisted applications only. Arguments are fixed here, never taken from the renderer.
const APPS = {
  word: { cmd: 'winword' },
  excel: { cmd: 'excel' },
  powerpoint: { cmd: 'powerpnt' },
  chrome: { cmd: 'chrome' },
  explorer: { cmd: 'explorer' },
  settings: { uri: 'ms-settings:' },
  bluetooth: { uri: 'ms-settings:bluetooth' },
  wifi: { uri: 'ms-settings:network-wifi' },
  whatsapp: { uri: 'whatsapp:' },
};

const SYSTEM_PROMPT =
  'You are ORVIA, a bilingual personal assistant for people who speak English and Somali (Af-Soomaali). ' +
  'Reply in the language the user writes in. If they mix both, reply in the dominant one. ' +
  'Be clear, accurate and concise, and say when you are unsure.';

let win = null;
let tray = null;

const file = (name) => path.join(app.getPath('userData'), name);

function logAction(action, detail = '') {
  try {
    fs.appendFileSync(file('activity.log'), `${new Date().toISOString()}\t${action}\t${detail}\n`);
  } catch { /* logging must never crash the app */ }
}

function loadSettings() {
  try {
    const raw = JSON.parse(fs.readFileSync(file('settings.json'), 'utf8'));
    const out = { ...DEFAULTS };
    for (const k of Object.keys(DEFAULTS)) if (k in raw) out[k] = raw[k];
    return out;
  } catch {
    return { ...DEFAULTS };
  }
}

function saveSettings(s) {
  fs.writeFileSync(file('settings.json'), JSON.stringify(s, null, 2));
}

function sanitizePatch(p) {
  const out = {};
  if (!p || typeof p !== 'object') return out;
  if ('language' in p && ['en', 'so'].includes(p.language)) out.language = p.language;
  if ('theme' in p && ['dark', 'light'].includes(p.theme)) out.theme = p.theme;
  if ('model' in p && typeof p.model === 'string' && /^[a-z0-9.\-]{3,100}$/i.test(p.model)) out.model = p.model;
  if ('closeToTray' in p) out.closeToTray = Boolean(p.closeToTray);
  if ('launchAtStartup' in p) out.launchAtStartup = Boolean(p.launchAtStartup);
  if ('voiceRate' in p && typeof p.voiceRate === 'number' && p.voiceRate >= 0.5 && p.voiceRate <= 2) {
    out.voiceRate = p.voiceRate;
  }
  return out;
}

function getApiKey() {
  try {
    if (!fs.existsSync(file('apikey.enc'))) return null;
    return safeStorage.decryptString(fs.readFileSync(file('apikey.enc')));
  } catch {
    return null;
  }
}

function sanitizeMessages(list) {
  if (!Array.isArray(list)) return [];
  const cleaned = list
    .slice(-30)
    .filter((m) => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string' && m.content.trim())
    .map((m) => ({ role: m.role, content: m.content.slice(0, 8000) }));
  while (cleaned.length && cleaned[0].role !== 'user') cleaned.shift();
  return cleaned;
}

async function launchApp(cfg) {
  if (cfg.uri) {
    await shell.openExternal(cfg.uri);
    return;
  }
  if (process.platform !== 'win32') throw new Error('WINDOWS_ONLY');
  // Fixed command from the whitelist; the empty string is the window title argument for "start".
  const child = spawn('cmd', ['/c', 'start', '', cfg.cmd], { detached: true, stdio: 'ignore', windowsHide: true });
  child.unref();
}

// ---------- IPC ----------
ipcMain.handle('settings:get', () => loadSettings());

ipcMain.handle('settings:set', (_e, patch) => {
  const clean = sanitizePatch(patch);
  const s = { ...loadSettings(), ...clean };
  saveSettings(s);
  if ('launchAtStartup' in clean) app.setLoginItemSettings({ openAtLogin: s.launchAtStartup });
  logAction('settings.update', Object.keys(clean).join(','));
  return s;
});

ipcMain.handle('key:has', () => fs.existsSync(file('apikey.enc')));

ipcMain.handle('key:set', (_e, key) => {
  if (typeof key !== 'string') return { ok: false, code: 'INVALID' };
  const k = key.trim();
  if (k.length < 20 || k.length > 300) return { ok: false, code: 'INVALID' };
  if (!safeStorage.isEncryptionAvailable()) return { ok: false, code: 'NO_SAFE_STORAGE' };
  fs.writeFileSync(file('apikey.enc'), safeStorage.encryptString(k));
  logAction('key.saved');
  return { ok: true };
});

ipcMain.handle('ai:chat', async (_e, messages) => {
  const key = getApiKey();
  if (!key) return { ok: false, code: 'NO_KEY' };
  const clean = sanitizeMessages(messages);
  if (!clean.length) return { ok: false, code: 'EMPTY' };
  const s = loadSettings();
  try {
    const res = await fetch(ANTHROPIC_URL, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': key,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({ model: s.model, max_tokens: 1024, system: SYSTEM_PROMPT, messages: clean }),
    });
    if (!res.ok) {
      logAction('ai.error', `HTTP ${res.status}`);
      return { ok: false, code: 'HTTP_' + res.status };
    }
    const data = await res.json();
    const text = (data.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('\n').trim();
    logAction('ai.chat', `${clean.length} messages`);
    return { ok: true, text };
  } catch {
    logAction('ai.error', 'network');
    return { ok: false, code: 'NETWORK' };
  }
});

ipcMain.handle('app:open', async (_e, id) => {
  if (typeof id !== 'string' || !Object.prototype.hasOwnProperty.call(APPS, id)) {
    return { ok: false, code: 'NOT_ALLOWED' };
  }
  try {
    await launchApp(APPS[id]);
  } catch (err) {
    logAction('app.error', id);
    return { ok: false, code: err.message === 'WINDOWS_ONLY' ? 'WINDOWS_ONLY' : 'LAUNCH_FAILED' };
  }
  const s = loadSettings();
  s.recentApps = [id, ...s.recentApps.filter((x) => x !== id)].slice(0, 6);
  saveSettings(s);
  logAction('app.open', id);
  return { ok: true };
});

ipcMain.handle('log:get', () => {
  try {
    const lines = fs.readFileSync(file('activity.log'), 'utf8').split('\n').filter(Boolean);
    return lines.slice(-200).reverse();
  } catch {
    return [];
  }
});

ipcMain.handle('system:info', () => ({
  platform: process.platform,
  cpus: os.cpus().length,
  freeMem: os.freemem(),
  totalMem: os.totalmem(),
  uptime: os.uptime(),
}));

// ---------- Window and tray ----------
function iconFile() {
  const ico = path.join(__dirname, '..', 'build', 'icon.ico');
  return fs.existsSync(ico) ? ico : undefined;
}

function createWindow() {
  win = new BrowserWindow({
    width: 1200,
    height: 800,
    minWidth: 900,
    minHeight: 600,
    backgroundColor: '#0b1020',
    title: 'ORVIA AI',
    icon: iconFile(),
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  win.once('ready-to-show', () => win.show());
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e) => e.preventDefault());
  if (process.env.ORVIA_DEV_URL) win.loadURL(process.env.ORVIA_DEV_URL);
  else win.loadFile(path.join(__dirname, '..', 'dist', 'index.html'));

  win.on('close', (e) => {
    if (!app.isQuitting && loadSettings().closeToTray) {
      e.preventDefault();
      win.hide();
    }
  });
}

function showWindow() {
  if (!win) return;
  if (win.isMinimized()) win.restore();
  win.show();
  win.focus();
}

function createTray() {
  const icon = iconFile() ? nativeImage.createFromPath(iconFile()) : nativeImage.createEmpty();
  tray = new Tray(icon);
  tray.setToolTip('ORVIA AI');
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Open ORVIA', click: showWindow },
    { type: 'separator' },
    { label: 'Quit', click: () => { app.isQuitting = true; app.quit(); } },
  ]));
  tray.on('click', showWindow);
}

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', showWindow);
  app.whenReady().then(() => {
    // Only allow microphone access; deny everything else.
    session.defaultSession.setPermissionRequestHandler((_wc, permission, callback) => {
      callback(permission === 'media');
    });
    createWindow();
    createTray();
    app.on('activate', showWindow);
    logAction('app.start');
  });
}
