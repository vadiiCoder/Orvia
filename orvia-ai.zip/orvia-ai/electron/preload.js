const { contextBridge, ipcRenderer } = require('electron');

// The only surface the renderer can reach. Every call goes through a named IPC channel.
const call = (channel) => (...args) => ipcRenderer.invoke(channel, ...args);

contextBridge.exposeInMainWorld('orvia', {
  getSettings: call('settings:get'),
  setSettings: call('settings:set'),
  hasKey: call('key:has'),
  setKey: call('key:set'),
  chat: call('ai:chat'),
  openApp: call('app:open'),
  getLog: call('log:get'),
  getSystemInfo: call('system:info'),
});
