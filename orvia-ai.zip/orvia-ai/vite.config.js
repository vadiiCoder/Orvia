import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Electron loads the bundle from file://, where ES module scripts are blocked.
// Emit a classic deferred script instead.
export default defineConfig({
  base: './',
  plugins: [
    react(),
    {
      name: 'orvia-classic-script',
      transformIndexHtml(html) {
        return html.replace(/<script type="module"[^>]*src="([^"]+)"[^>]*><\/script>/g,
          '<script defer src="$1"></script>');
      },
    },
  ],
  build: {
    outDir: 'dist',
    rollupOptions: { output: { format: 'iife', inlineDynamicImports: true } },
  },
});
