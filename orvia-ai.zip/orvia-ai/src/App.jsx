import React, { useEffect, useRef, useState } from 'react';
import { t, LANGS } from './i18n.js';

const api = window.orvia;

// Pages marked ready are implemented. Others show an honest "planned" card.
const PAGES = [
  { id: 'dashboard', icon: '◎', ready: true },
  { id: 'chat', icon: '✦', ready: true },
  { id: 'voice', icon: '🎙', ready: true },
  { id: 'translation', icon: '⇄', ready: false },
  { id: 'study', icon: '📚', ready: false },
  { id: 'reader', icon: '📄', ready: false },
  { id: 'computer', icon: '⌘', ready: true },
  { id: 'files', icon: '🗂', ready: false },
  { id: 'music', icon: '♫', ready: false },
  { id: 'whatsapp', icon: '💬', ready: false },
  { id: 'productivity', icon: '⏱', ready: false },
  { id: 'notes', icon: '✎', ready: false },
  { id: 'history', icon: '🕘', ready: false },
  { id: 'settings', icon: '⚙', ready: true },
];

const APP_KEYWORDS = [
  ['file explorer', 'explorer'],
  ['explorer', 'explorer'],
  ['windows settings', 'settings'],
  ['bluetooth', 'bluetooth'],
  ['wi-fi', 'wifi'],
  ['wifi', 'wifi'],
  ['powerpoint', 'powerpoint'],
  ['powerpnt', 'powerpoint'],
  ['excel', 'excel'],
  ['word', 'word'],
  ['chrome', 'chrome'],
  ['whatsapp', 'whatsapp'],
];

// Understands "ORVIA, open Microsoft Word." and "ORVIA, fur Microsoft Word." Returns an app id or null.
export function parseOpenCommand(text) {
  const m = text.trim().match(/^(?:hey\s+)?(?:orvia[,!.]?\s*)?(?:open|fur)\s+(.+)$/i);
  if (!m) return null;
  const target = m[1].toLowerCase();
  for (const [kw, id] of APP_KEYWORDS) {
    if (new RegExp('\\b' + kw + '\\b').test(target)) return id;
  }
  return null;
}

function speak(text, settings) {
  if (!('speechSynthesis' in window)) return;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = settings.language === 'so' ? 'so-SO' : 'en-US';
  u.rate = settings.voiceRate || 1;
  window.speechSynthesis.speak(u);
}

const stopSpeaking = () => window.speechSynthesis?.cancel();

function listenOnce(lang, onText, onDone) {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) return null;
  const r = new SR();
  r.lang = lang === 'so' ? 'so-SO' : 'en-US';
  r.interimResults = false;
  r.maxAlternatives = 1;
  r.onresult = (e) => onText(e.results[0][0].transcript);
  r.onerror = () => onDone();
  r.onend = () => onDone();
  r.start();
  return r;
}

function formatGB(bytes) {
  return (bytes / 1024 ** 3).toFixed(1) + ' GB';
}

export default function App() {
  const [settings, setSettings] = useState(null);
  const [page, setPage] = useState('dashboard');
  const [online, setOnline] = useState(navigator.onLine);
  const [messages, setMessages] = useState([]);
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState(null);

  useEffect(() => { api.getSettings().then(setSettings); }, []);

  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => {
      window.removeEventListener('online', on);
      window.removeEventListener('offline', off);
    };
  }, []);

  useEffect(() => {
    if (!settings) return;
    document.documentElement.lang = settings.language;
    document.documentElement.dataset.theme = settings.theme;
  }, [settings]);

  if (!settings) return <div className="splash">ORVIA AI</div>;

  const lang = settings.language;
  const T = (k) => t(lang, k);

  const patch = async (p) => setSettings(await api.setSettings(p));

  const notify = (text) => {
    setToast(text);
    setTimeout(() => setToast(null), 2600);
  };

  const errorText = (code) => {
    if (code === 'NO_KEY') return T('noKey');
    if (code === 'NETWORK') return T('offlineAI');
    return `${T('error')}: ${code}`;
  };

  const runApp = async (id) => {
    const res = await api.openApp(id);
    if (res.ok) {
      setSettings(await api.getSettings());
      return `${T('launched')}: ${T('app.' + id)}`;
    }
    if (res.code === 'WINDOWS_ONLY') return `${T('error')}: ${T('winOnly')}`;
    return `${T('error')}: ${T('launchFailed')}`;
  };

  const send = async (raw) => {
    const text = (raw || '').trim();
    if (!text || busy) return null;
    const userMsg = { id: Date.now(), role: 'user', content: text };
    const nextHistory = [...messages, userMsg];
    setMessages(nextHistory);

    let reply;
    const appId = parseOpenCommand(text);
    if (appId) {
      reply = await runApp(appId);
    } else {
      setBusy(true);
      const res = await api.chat(nextHistory.map(({ role, content }) => ({ role, content })));
      setBusy(false);
      reply = res.ok ? res.text : errorText(res.code);
    }
    setMessages((m) => [...m, { id: Date.now() + 1, role: 'assistant', content: reply }]);
    return reply;
  };

  const toggleLang = () => patch({ language: lang === 'en' ? 'so' : 'en' });
  const toggleTheme = () => patch({ theme: settings.theme === 'dark' ? 'light' : 'dark' });

  const shared = { T, lang, settings, patch, send, messages, busy, runApp, notify, setPage };

  const current = PAGES.find((p) => p.id === page);

  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="logo">O</div>
          <div>
            <div className="brand-name">{T('appName')}</div>
            <div className="brand-tag">{T('tagline')}</div>
          </div>
        </div>
        <nav>
          {PAGES.map((p) => (
            <button
              key={p.id}
              className={'nav-item' + (page === p.id ? ' active' : '') + (p.ready ? '' : ' muted')}
              onClick={() => setPage(p.id)}
            >
              <span className="nav-icon">{p.icon}</span>
              <span>{T('nav.' + p.id)}</span>
            </button>
          ))}
        </nav>
        <div className="sidebar-foot">{T('fileNotes')}: 0.1.0</div>
      </aside>

      <div className="main">
        <header className="topbar">
          <h1>{T('nav.' + page)}</h1>
          <div className="top-actions">
            <span className={'pill ' + (online ? 'ok' : 'warn')}>
              <span className="dot" /> {online ? T('online') : T('offline')}
            </span>
            <span className="pill">{LANGS.find((l) => l.code === lang).label}</span>
            <button className="ghost" onClick={toggleLang} title={T('language')}>
              {lang === 'en' ? 'SO' : 'EN'}
            </button>
            <button className="ghost" onClick={toggleTheme} title={T('theme')}>
              {settings.theme === 'dark' ? T('light') : T('dark')}
            </button>
          </div>
        </header>

        <main className="content">
          {page === 'dashboard' && <Dashboard {...shared} />}
          {page === 'chat' && <ChatPage {...shared} />}
          {page === 'voice' && <VoicePage {...shared} />}
          {page === 'computer' && <ComputerPage {...shared} />}
          {page === 'settings' && <SettingsPage {...shared} />}
          {!current?.ready && <PlannedPage T={T} />}
        </main>

        {toast && <div className="toast">{toast}</div>}
      </div>
    </div>
  );
}

function Dashboard({ T, settings, messages, runApp, setPage, notify }) {
  const [sys, setSys] = useState(null);
  useEffect(() => { api.getSystemInfo().then(setSys); }, []);
  const recentUser = messages.filter((m) => m.role === 'user').slice(-5).reverse();
  const quick = ['word', 'excel', 'powerpoint', 'chrome', 'explorer', 'whatsapp'];

  return (
    <div className="grid">
      <section className="card hero span-2">
        <div className="orb-small" />
        <div>
          <h2>{T('welcome')}</h2>
          <p className="muted">{T('tagline')}</p>
          <div className="row">
            <button className="primary" onClick={() => setPage('voice')}>🎙 {T('speak')}</button>
            <button className="ghost" onClick={() => setPage('chat')}>✦ {T('nav.chat')}</button>
          </div>
        </div>
      </section>

      <section className="card">
        <h3>{T('systemStatus')}</h3>
        {sys ? (
          <ul className="kv">
            <li><span>{T('platform')}</span><b>{sys.platform}</b></li>
            <li><span>{T('cpu')}</span><b>{sys.cpus}</b></li>
            <li><span>{T('memory')}</span><b>{formatGB(sys.freeMem)} / {formatGB(sys.totalMem)}</b></li>
          </ul>
        ) : <p className="muted">…</p>}
      </section>

      <section className="card span-2">
        <h3>{T('quickActions')}</h3>
        <div className="chips">
          {quick.map((id) => (
            <button key={id} className="chip" onClick={async () => notify(await runApp(id))}>
              {T('app.' + id)}
            </button>
          ))}
        </div>
        <p className="muted small">{T('computerHint')}</p>
      </section>

      <section className="card">
        <h3>{T('recentApps')}</h3>
        {settings.recentApps.length ? (
          <div className="chips">
            {settings.recentApps.map((id) => (
              <button key={id} className="chip" onClick={async () => notify(await runApp(id))}>{T('app.' + id)}</button>
            ))}
          </div>
        ) : <p className="muted">—</p>}
      </section>

      <section className="card span-3">
        <h3>{T('recentConversations')}</h3>
        {recentUser.length ? (
          <ul className="list">
            {recentUser.map((m) => <li key={m.id}>{m.content}</li>)}
          </ul>
        ) : <p className="muted">{T('noConversations')}</p>}
      </section>
    </div>
  );
}

function ChatPage({ T, messages, send, busy }) {
  const [input, setInput] = useState('');
  const endRef = useRef(null);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages.length, busy]);

  const submit = (e) => {
    e.preventDefault();
    const v = input;
    setInput('');
    send(v);
  };

  return (
    <div className="chat">
      <div className="thread">
        {messages.length === 0 && <p className="muted center">{T('welcome')}</p>}
        {messages.map((m) => (
          <div key={m.id} className={'bubble ' + m.role}>{m.content}</div>
        ))}
        {busy && <div className="bubble assistant muted">{T('thinking')}</div>}
        <div ref={endRef} />
      </div>
      <form className="composer" onSubmit={submit}>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={T('typeMessage')}
          dir="auto"
        />
        <button className="primary" type="submit" disabled={busy || !input.trim()}>{T('send')}</button>
      </form>
    </div>
  );
}

function VoicePage({ T, lang, settings, send, messages }) {
  const [listening, setListening] = useState(false);
  const [heard, setHeard] = useState('');
  const recRef = useRef(null);
  const supported = !!(window.SpeechRecognition || window.webkitSpeechRecognition);
  const lastReply = [...messages].reverse().find((m) => m.role === 'assistant');

  const toggle = () => {
    if (listening) {
      recRef.current?.stop();
      setListening(false);
      return;
    }
    stopSpeaking();
    setListening(true);
    recRef.current = listenOnce(
      lang,
      async (text) => {
        setListening(false);
        setHeard(text);
        const reply = await send(text);
        if (reply) speak(reply, settings);
      },
      () => setListening(false),
    );
  };

  return (
    <div className="voice">
      <p className="muted center">{supported ? T('voiceHint') : T('voiceUnsupported')}</p>
      <div className={'orb' + (listening ? ' live' : '')}>
        <div className="orb-core" />
      </div>
      <div className="row center">
        <button className="mic" onClick={toggle} disabled={!supported} aria-label={T('speak')}>
          {listening ? '●' : '🎙'}
        </button>
        <button className="ghost" onClick={stopSpeaking}>{T('stopSpeaking')}</button>
        <button className="ghost" onClick={() => lastReply && speak(lastReply.content, settings)} disabled={!lastReply}>
          ↻
        </button>
      </div>
      {listening && <p className="muted">{T('listening')}</p>}
      {heard && <p className="heard">“{heard}”</p>}
      {lastReply && <div className="bubble assistant wide">{lastReply.content}</div>}
    </div>
  );
}

function ComputerPage({ T, runApp, notify }) {
  const ids = ['word', 'excel', 'powerpoint', 'chrome', 'explorer', 'settings', 'bluetooth', 'wifi', 'whatsapp'];
  return (
    <div className="grid">
      <section className="card span-3">
        <p className="muted">{T('computerHint')}</p>
      </section>
      {ids.map((id) => (
        <button key={id} className="card app-card" onClick={async () => notify(await runApp(id))}>
          <span className="app-name">{T('app.' + id)}</span>
          <span className="muted small">{id}</span>
        </button>
      ))}
    </div>
  );
}

function SettingsPage({ T, lang, settings, patch, notify }) {
  const [key, setKey] = useState('');
  const [hasKey, setHasKey] = useState(false);
  const [log, setLog] = useState([]);
  const [model, setModel] = useState(settings.model);

  useEffect(() => {
    api.hasKey().then(setHasKey);
    api.getLog().then(setLog);
  }, []);

  const saveKey = async () => {
    const res = await api.setKey(key);
    if (res.ok) {
      setKey('');
      setHasKey(true);
      notify(T('keySaved'));
    } else if (res.code === 'INVALID') notify(T('keyInvalid'));
    else notify(T('keyFailed'));
  };

  return (
    <div className="grid">
      <section className="card">
        <h3>{T('general')}</h3>
        <label className="field">
          <span>{T('language')}</span>
          <select value={lang} onChange={(e) => patch({ language: e.target.value })}>
            {LANGS.map((l) => <option key={l.code} value={l.code}>{l.label}</option>)}
          </select>
        </label>
        <label className="field">
          <span>{T('theme')}</span>
          <select value={settings.theme} onChange={(e) => patch({ theme: e.target.value })}>
            <option value="dark">{T('dark')}</option>
            <option value="light">{T('light')}</option>
          </select>
        </label>
        <label className="check">
          <input type="checkbox" checked={settings.closeToTray} onChange={(e) => patch({ closeToTray: e.target.checked })} />
          {T('closeToTray')}
        </label>
        <label className="check">
          <input type="checkbox" checked={settings.launchAtStartup} onChange={(e) => patch({ launchAtStartup: e.target.checked })} />
          {T('launchAtStartup')}
        </label>
      </section>

      <section className="card">
        <h3>{T('ai')}</h3>
        <label className="field">
          <span>{T('apiKey')} {hasKey ? '✓' : ''}</span>
          <div className="row">
            <input type="password" value={key} onChange={(e) => setKey(e.target.value)} autoComplete="off" />
            <button className="primary" onClick={saveKey} disabled={!key.trim()}>{T('saveKey')}</button>
          </div>
        </label>
        <label className="field">
          <span>{T('model')}</span>
          <div className="row">
            <input value={model} onChange={(e) => setModel(e.target.value)} />
            <button className="ghost" onClick={() => patch({ model })}>{T('save')}</button>
          </div>
        </label>
      </section>

      <section className="card">
        <h3>{T('voiceSettings')}</h3>
        <label className="field">
          <span>{T('voiceRate')}: {settings.voiceRate.toFixed(1)}×</span>
          <input type="range" min="0.5" max="2" step="0.1" value={settings.voiceRate}
            onChange={(e) => patch({ voiceRate: Number(e.target.value) })} />
        </label>
      </section>

      <section className="card span-3">
        <h3>{T('activityLog')}</h3>
        {log.length ? <pre className="log">{log.join('\n')}</pre> : <p className="muted">{T('noLog')}</p>}
      </section>

      <section className="card span-3">
        <h3>{T('about')}</h3>
        <p className="muted">ORVIA AI · {T('version')} 0.1.0</p>
      </section>
    </div>
  );
}

function PlannedPage({ T }) {
  return (
    <section className="card planned">
      <h3>{T('planned')}</h3>
      <p className="muted">{T('plannedDesc')}</p>
    </section>
  );
}
